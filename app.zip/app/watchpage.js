var spinnerParent = document.querySelector("#app");
spinner();
var spinner = document.querySelector(".spinner-container.full-height");
spinner.setAttribute("hidden", "");

/* const headerBar = document.querySelector("ytm15-header-bar"); */
if (headerBar) {
headerBar.setAttribute('hidden', '');
}